from http.server import BaseHTTPRequestHandler
import json
import os
import math
from datetime import datetime

# Path references
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(BASE_DIR, "models", "iris_rf_model_full.joblib")
PORTABLE_PATH = os.path.join(BASE_DIR, "portable_model.json")
METADATA_PATH = os.path.join(BASE_DIR, "model_metadata.json")

# Lazy-loaded globals
_JOB_MODEL = None
_PORTABLE_MODEL = None
_METADATA = None

def load_resources():
    global _JOB_MODEL, _PORTABLE_MODEL, _METADATA
    if _METADATA is None and os.path.exists(METADATA_PATH):
        try:
            with open(METADATA_PATH, "r") as f:
                _METADATA = json.load(f)
        except Exception:
            _METADATA = {}

    if _PORTABLE_MODEL is None and os.path.exists(PORTABLE_PATH):
        try:
            with open(PORTABLE_PATH, "r") as f:
                _PORTABLE_MODEL = json.load(f)
        except Exception:
            _PORTABLE_MODEL = None

    if _JOB_MODEL is None and os.path.exists(MODEL_PATH):
        try:
            import joblib
            _JOB_MODEL = joblib.load(MODEL_PATH)
        except Exception:
            _JOB_MODEL = None

def predict_portable(features, portable):
    # features: [sepal_length, sepal_width, petal_length, petal_width]
    mean = portable["scaler_mean"]
    scale = portable["scaler_scale"]
    coef = portable["lr_coef"]
    intercept = portable["lr_intercept"]
    classes = portable["classes"]

    # Scale
    x_scaled = [(features[i] - mean[i]) / scale[i] for i in range(4)]

    # Linear scores
    scores = []
    for c_idx in range(len(classes)):
        score = intercept[c_idx]
        for f_idx in range(4):
            score += coef[c_idx][f_idx] * x_scaled[f_idx]
        scores.append(score)

    # Softmax
    max_score = max(scores)
    exp_scores = [math.exp(s - max_score) for s in scores]
    sum_exp = sum(exp_scores)
    probs = [round(e / sum_exp, 5) for e in exp_scores]

    best_idx = probs.index(max(probs))
    return classes[best_idx], best_idx, probs, {classes[i]: probs[i] for i in range(len(classes))}

def predict_joblib(features, model):
    import numpy as np
    x_arr = np.array([features])
    pred_idx = int(model.predict(x_arr)[0])
    probs = model.predict_proba(x_arr)[0].tolist()
    classes = ["setosa", "versicolor", "virginica"]
    pred_class = classes[pred_idx]
    probs_dict = {classes[i]: round(float(probs[i]), 5) for i in range(len(classes))}
    return pred_class, pred_idx, probs, probs_dict

class handler(BaseHTTPRequestHandler):
    def _set_headers(self, status=200, content_type="application/json"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_OPTIONS(self):
        self._set_headers(200)

    def do_GET(self):
        load_resources()
        info = {
            "service": "Iris Dataset Classification API",
            "version": "1.0.0",
            "status": "healthy",
            "model_type": "Random Forest / Multi-class Classifier",
            "features": [
                {"name": "sepal_length", "unit": "cm", "min": 4.3, "max": 7.9, "default": 5.8},
                {"name": "sepal_width",  "unit": "cm", "min": 2.0, "max": 4.4, "default": 3.0},
                {"name": "petal_length", "unit": "cm", "min": 1.0, "max": 6.9, "default": 3.7},
                {"name": "petal_width",  "unit": "cm", "min": 0.1, "max": 2.5, "default": 1.2}
            ],
            "classes": ["setosa", "versicolor", "virginica"],
            "sample_requests": {
                "setosa": {"sepal_length": 5.1, "sepal_width": 3.5, "petal_length": 1.4, "petal_width": 0.2},
                "versicolor": {"sepal_length": 5.9, "sepal_width": 3.0, "petal_length": 4.2, "petal_width": 1.5},
                "virginica": {"sepal_length": 6.7, "sepal_width": 3.3, "petal_length": 5.7, "petal_width": 2.5}
            },
            "metrics": _METADATA.get("evaluation_metrics", {}) if _METADATA else {}
        }
        self._set_headers(200)
        self.wfile.write(json.dumps(info, indent=2).encode("utf-8"))

    def do_POST(self):
        load_resources()
        content_length = int(self.headers.get("Content-Length", 0))
        if content_length == 0:
            self._set_headers(400)
            self.wfile.write(json.dumps({"error": "Empty request body"}).encode("utf-8"))
            return

        body = self.rfile.read(content_length).decode("utf-8")
        try:
            data = json.loads(body)
        except Exception as e:
            self._set_headers(400)
            self.wfile.write(json.dumps({"error": f"Invalid JSON: {str(e)}"}).encode("utf-8"))
            return

        # Extract features
        try:
            if "features" in data and isinstance(data["features"], list):
                feat_vals = [float(v) for v in data["features"]]
            else:
                sl = float(data.get("sepal_length", data.get("sepal length (cm)", 5.8)))
                sw = float(data.get("sepal_width", data.get("sepal width (cm)", 3.0)))
                pl = float(data.get("petal_length", data.get("petal length (cm)", 3.7)))
                pw = float(data.get("petal_width", data.get("petal width (cm)", 1.2)))
                feat_vals = [sl, sw, pl, pw]

            if len(feat_vals) != 4:
                raise ValueError("Expected exactly 4 features [sepal_length, sepal_width, petal_length, petal_width]")

            # Run inference
            engine = "portable_softmax"
            if _JOB_MODEL is not None:
                try:
                    pred_class, pred_idx, raw_probs, probs_dict = predict_joblib(feat_vals, _JOB_MODEL)
                    engine = "random_forest_joblib"
                except Exception:
                    pred_class, pred_idx, raw_probs, probs_dict = predict_portable(feat_vals, _PORTABLE_MODEL)
            elif _PORTABLE_MODEL is not None:
                pred_class, pred_idx, raw_probs, probs_dict = predict_portable(feat_vals, _PORTABLE_MODEL)
            else:
                raise RuntimeError("No model weights or serialized model available")

            response = {
                "status": "success",
                "prediction": pred_class,
                "class_index": pred_idx,
                "confidence": probs_dict[pred_class],
                "probabilities": probs_dict,
                "engine": engine,
                "input_features": {
                    "sepal_length": feat_vals[0],
                    "sepal_width": feat_vals[1],
                    "petal_length": feat_vals[2],
                    "petal_width": feat_vals[3]
                },
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }

            self._set_headers(200)
            self.wfile.write(json.dumps(response, indent=2).encode("utf-8"))

        except Exception as e:
            self._set_headers(400)
            self.wfile.write(json.dumps({"error": str(e)}).encode("utf-8"))
