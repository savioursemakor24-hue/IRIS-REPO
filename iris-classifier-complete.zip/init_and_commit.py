import os
import sys
from dulwich import porcelain
from dulwich.repo import Repo

REPO_PATH = os.path.dirname(os.path.abspath(__file__))

print(f"[*] Initializing Git repository in {REPO_PATH}...")
if not os.path.exists(os.path.join(REPO_PATH, ".git")):
    repo = porcelain.init(REPO_PATH)
else:
    repo = Repo(REPO_PATH)

print("[*] Staging files...")
# Read .gitignore patterns
ignore_patterns = [".venv", "__pycache__", "predictions_history.db", ".git"]

files_to_add = []
for root, dirs, files in os.walk(REPO_PATH):
    # Skip ignored dirs
    dirs[:] = [d for d in dirs if d not in [".venv", "__pycache__", ".git"]]
    for f in files:
        if f.endswith(".pyc") or f == "predictions_history.db":
            continue
        rel_path = os.path.relpath(os.path.join(root, f), REPO_PATH)
        files_to_add.append(rel_path.replace("\\", "/"))

print(f"[*] Adding {len(files_to_add)} files to git index...")
porcelain.add(REPO_PATH, files_to_add)

print("[*] Creating initial commit...")
author = b"Antigravity User <user@example.com>"
commit_msg = b"Initial commit: Iris classification ML model, pure HTML/CSS Flask web app, Vercel & Docker configs"
try:
    commit_sha = porcelain.commit(
        REPO_PATH,
        message=commit_msg,
        author=author,
        committer=author
    )
    print(f"[+] Successfully committed: {commit_sha.decode('ascii')}")
except Exception as e:
    print(f"[*] Commit status: {e}")

# Check status
status = porcelain.status(REPO_PATH)
print(f"[*] Git Status: {status}")
