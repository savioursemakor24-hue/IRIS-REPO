import os
import sys
from dulwich import porcelain
from dulwich.repo import Repo

REPO_PATH = os.path.dirname(os.path.abspath(__file__))
REMOTE_URL = "https://github.com/savioursemakor24-hue/IRIS-REPO.git"

print(f"[*] Repository directory: {REPO_PATH}")
print(f"[*] Remote target: {REMOTE_URL}")

repo = Repo(REPO_PATH)

# Set remote origin
config = repo.get_config()
config.set(('remote', 'origin'), 'url', REMOTE_URL)
config.write_to_path()

print("[*] Attempting git push to origin main...")
try:
    porcelain.push(repo, REMOTE_URL, "refs/heads/main:refs/heads/main")
    print("[+] Successfully pushed to GitHub!")
except Exception as e:
    print(f"[!] Push result/error: {type(e).__name__}: {e}")
