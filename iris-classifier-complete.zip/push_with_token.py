import sys
import os
from dulwich import porcelain
from dulwich.repo import Repo

REPO_PATH = os.path.dirname(os.path.abspath(__file__))

if len(sys.argv) < 2:
    print("Usage: python push_with_token.py <GITHUB_PERSONAL_ACCESS_TOKEN>")
    sys.exit(1)

token = sys.argv[1].strip()
target_url = f"https://{token}@github.com/savioursemakor24-hue/IRIS-REPO.git"

print(f"[*] Pushing local branch 'main' to https://github.com/savioursemakor24-hue/IRIS-REPO.git ...")
try:
    porcelain.push(REPO_PATH, target_url, "refs/heads/main:refs/heads/main")
    print("\n[SUCCESS] Entire project has been pushed successfully to https://github.com/savioursemakor24-hue/IRIS-REPO!")
except Exception as e:
    print(f"\n[!] Push failed: {e}")
    sys.exit(1)
