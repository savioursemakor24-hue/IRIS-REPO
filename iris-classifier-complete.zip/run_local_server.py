import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from app import app

if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    print(f"[*] Starting Iris Python Web Application at: http://localhost:{port}")
    print(f"[*] HTML Web Interface: http://localhost:{port}/")
    print(f"[*] Prediction API Endpoint: http://localhost:{port}/api/predict")
    print("[*] Press Ctrl+C to terminate.")
    app.run(host="127.0.0.1", port=port, debug=False)
