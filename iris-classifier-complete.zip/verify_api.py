import sys
import os
import json
from io import BytesIO

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(BASE_DIR, "api"))
import predict

def test_inference():
    print("Testing Iris Prediction API...")

    test_cases = [
        {"name": "Setosa benchmark", "input": {"sepal_length": 5.1, "sepal_width": 3.5, "petal_length": 1.4, "petal_width": 0.2}, "expected": "setosa"},
        {"name": "Versicolor benchmark", "input": {"sepal_length": 5.9, "sepal_width": 3.0, "petal_length": 4.2, "petal_width": 1.5}, "expected": "versicolor"},
        {"name": "Virginica benchmark", "input": {"sepal_length": 6.5, "sepal_width": 3.0, "petal_length": 5.5, "petal_width": 1.8}, "expected": "virginica"}
    ]

    all_passed = True
    for case in test_cases:
        feat_vals = [
            case["input"]["sepal_length"],
            case["input"]["sepal_width"],
            case["input"]["petal_length"],
            case["input"]["petal_width"]
        ]
        
        # Test portable inference
        pred_class, pred_idx, probs, probs_dict = predict.predict_portable(feat_vals, predict._PORTABLE_MODEL or json.load(open(os.path.join(BASE_DIR, "portable_model.json"))))
        passed = (pred_class == case["expected"])
        status = "PASSED" if passed else "FAILED"
        print(f"[{status}] {case['name']}: Expected={case['expected']}, Predicted={pred_class}, Confidence={probs_dict[pred_class]*100:.1f}%")
        if not passed:
            all_passed = False

    if all_passed:
        print("\nAll API verification tests passed successfully!")
    else:
        print("\nSome tests failed!")
        sys.exit(1)

if __name__ == "__main__":
    test_inference()
